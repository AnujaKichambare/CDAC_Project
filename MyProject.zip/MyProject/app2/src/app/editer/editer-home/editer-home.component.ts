import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editer-home',
  templateUrl: './editer-home.component.html',
  styleUrls: ['./editer-home.component.css']
})
export class EditerHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
