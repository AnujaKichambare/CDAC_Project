import { Component, OnInit } from '@angular/core';
import { EditerService } from '../editer.service';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/login/login.service';

@Component({
  selector: 'app-addnews',
  templateUrl: './addnews.component.html',
  styleUrls: ['./addnews.component.css']
})
export class AddnewsComponent implements OnInit {
list:any;
flag=false;
catagory;
language;
  constructor(public service:LoginService,public router:Router,public editorservice:EditerService) { }

  ngOnInit() {
  }

  getdata()
  {
    let stateofresult=this.service.getlistofcatagory();
stateofresult.subscribe((result)=>{
this.list=result;  
//this.router.navigate(['Reader']);
});
  }

  setcatagory(c:any)
  {
    this.catagory=c.category_id;
  }

  setlanguage(language)
  {
   if(language=="English")
   {
this.flag=true;
this.language=language;
   }else
   {
    this.flag=false;     
    this.language=language;
   }
    
  }
  
  uplodenews(news)
  {
    //alert(news.image_video+news);
    //alert(news.news_link);
    //alert(news.language);
    //alert(news.news_title);
    //alert(news.news_description);
    this.editorservice.addnews(news,this.catagory).subscribe((result)=>{

    },err=>{

    })
  }


}
