import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/login/login.service';
import { EditerService } from '../editer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
msg;
  constructor(public router:Router,public service:EditerService) { }

  ngOnInit() {
  }

  addempl(dataFromUI:any)
  {
  let reg=dataFromUI.form.value;
  console.log(reg);
  let stateofresult=this.service.adddata(reg)
  stateofresult.subscribe((result)=>{
    console.log(result);
      this.msg="registere clear and all more";
  },err=>{ 
    this.msg="Failed";
  });
  }
}
