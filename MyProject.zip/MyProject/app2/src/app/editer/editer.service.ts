import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EditerService {

  constructor(public http:HttpClient) { }

  adddata(reg)
  {
    return this.http.post("http://localhost:5600/Editer/register",reg);
  }
  getdatabyid(writer_id:any)
  {
    return this.http.get("http://localhost:5600/Editer/getwriter/"+writer_id);
  }
  deletewriter(id:any)
  {
    return this.http.get("http://localhost:5600/Editer/deletewriter/"+id);
  }
  editwriter(user:any)
  {
  return this.http.post("http://localhost:5600/Editer/editwriter",user);
  }
  getlistofwriter()
  {
    return this.http.get("http://localhost:5600/Editer/listofwriter");
  }
  registermsg(reg:any)
  {
    return this.http.post("http://localhost:5600/login/registermsg",reg);
  }

  changepassword(email_id:string,password)
  {
    return this.http.get("http://localhost:5600/Editer/changepassword/"+email_id+"/"+password);
  }

  addpoll(poll:any)
  {
    return this.http.post("http://localhost:5600/Editer/addpoll",poll);
  }

  getpoll()
  {
    return this.http.get("http://localhost:5600/Editer/getpoll");
  }

  setanswer(id,ans)
  {
    return this.http.get("http://localhost:5600/Editer/setanswer/"+id+"/"+ans);
  }

  deletepoll(id:any)
  {
    return this.http.get("http://localhost:5600/Editer/deletepoll/"+id);
  }

  addnews(news:any,cid)
  {
    return this.http.put("http://localhost:5600/Editer/addnews/"+cid,news);
  }

  getunuploadednews()
  {
    return this.http.get("http://localhost:5600/Editer/getunuploadednews");
  }

  getuploadednews(language)
  {
    return this.http.get("http://localhost:5600/Editer/getuploadednews/"+language);
  }

  uploadednews(id)
  {
    return this.http.get("http://localhost:5600/Editer/uploadednews/"+id);
  }


  deletenews(id)
  {
    return this.http.get("http://localhost:5600/Editer/deletenews/"+id);
  }

  getnewsbycategory(category,language)
  {
    return this.http.get("http://localhost:5600/Editer/getnewsbycategory/"+category+"/"+language);
  }

  getallnews()
  {
    return this.http.get("http://localhost:5600/Editer/getallnews");
  }

  unuploadnews(id)
  {
    return this.http.get("http://localhost:5600/Editer/unuploadnews/"+id);
  }

  editnews(cat,nid,news)
  {
    return this.http.put("http://localhost:5600/Editer/editnews/"+cat+"/"+nid,news);
  }

  uploadnews(nid)
  {
    return this.http.get("http://localhost:5600/Editer/uploadnews/"+nid);
  }

getsinglenews(nid)
{
  return this.http.get("http://localhost:5600/Editer/getsinglenews/"+nid);
}

getpollanswer(pollid)
{
  return this.http.get("http://localhost:5600/Editer/getpollanswer/"+pollid);
}

getnewsbydate(lang,sdate)
{
  return this.http.get("http://localhost:5600/Editer/getnewsbydate/"+lang+"/"+sdate);
}

addcategory(add)
{
  return this.http.get("http://localhost:5600/Editer/addcategory/"+add);
}

}
