import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from './login.service';
import { AuthService } from '../auth.service';
import { forEach } from '@angular/router/src/utils/collection';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
msg;
user:any;
  constructor(public router:Router,public service:LoginService,public routers:ActivatedRoute,public authservice:AuthService) { 
    sessionStorage.clear();
  }

  ngOnInit() {
  }
  Login(cd:any) {
    let c=cd.form.value;
    c.e
      if (c.email_id.length == 0) 
      {
        this.msg='enter valid email';
      } else if(c.password.length == 0) 
      {
        this.msg='enter valid password';
      } else 
      {
   

        
        //let checku =this.service.login(c);  
        //console.log(checku);
        //checku.subscribe((result:any)=>{
          this.service.login(c).subscribe(result=>{  
          
          this.user=result;
            alert(this.user[0].t_role);
          if(this.user[0].t_role=="e")
          {
            sessionStorage['user']=[this.user[0].writer_id,this.user[0].email_id,this.user[0].name,this.user[0].t_role];
            this.router.navigate(['editer']);
                  }else
                  {
                    sessionStorage['user']=[this.user[0].writer_id];
                  this.router.navigate(['writerhome']);
                  }
        },err=>{
          this.user=err;
            alert(this.user);
          this.msg='enter valid password/email';
          //this.router.navigate(['login']);
        });  
      }
    }
    forgotpassword()
    {
      this.router.navigate(['Forgotpassword']);
    }

    gobacktohome()
    {
      this.router.navigate(['Reader']);
    }
}
