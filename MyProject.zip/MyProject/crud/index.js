const express=require('express')
const bodyparser=require('body-parser')

//const routerWriter=require('./route/writer')
const editor=require('./route/editor')
const login=require('./route/login')
const category=require('./route/category')

const app=express()
app.use(function(req,res,next){
    res.header("Access-Control-Allow-Origin", "*"); // update to match the domain you will make the request from
    res.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE"); // update to match the domain you will make the request from
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(bodyparser.json())
//app.use('/writer',routerWriter)
app.use('/Editer',editor)
app.use('/login',login)
app.use('/category',category)


app.listen(5600,'0.0.0.0',()=>{
    console.log('server started on port no 5600')
})