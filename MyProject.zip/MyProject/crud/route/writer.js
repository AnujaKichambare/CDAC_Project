const db=require('./db')
const utils=require('./utils')
const express =require('express')

const router=express.Router();


// router.get('/',(request,response)=>{
//     const connection=db.connect()
//     if(connection==null)
//     response.send("Connection is null")

//     const statement='select * from t_writer'
//     connection.query(statement,(error,data)=>{
//         connection.end()
//         response.send(utils.createresult(error,data))
//     })
// })

// router.post('/login_w', (request, response) => {
//     const {email_id, password} = request.body
//     const connection = db.connect()
//     const statement = `select t_role from t_writer where email_id='${email_id}' && password='${password}'`
//     connection.query(statement, (error, data) => {
//         connection.end()
//         response.send(utils.createresult(error,data))
        
    
//     })
// })

router.post('/reg_w',(request,response)=>{
    const{name,gender,email_id,mobile_no,address,dob,password,t_role}=request.body
    const connection=db.connect()
    const statement=`insert into t_writer (name,gender,email_id,mobile_no,address,dob,password,t_role) values('${name}','${gender}','${email_id}','${mobile_no}','${address}','${dob}','${password}','${t_role}')`
    connection.query(statement,(error,data)=>{
        connection.end()
        response.send(utils.createresult(error,data))
    })
})

router.get('/',(request,response)=>{
    const connection=db.connect()
    const statement=`select * from t_writer where t_role='w'`
    connection.query(statement,(error,data)=>{
        connection.end()
        response.send(utils.createresult(error,data))
    })
})
// router.get("/",function(request,response){
//     const connection=db.connect()
//     connection.query(`select * from t_writer where t_role='w'`,function(err,result){
//         if(err==null)
//         { 
//     response.contentType("application/json");
//     response.send(JSON.stringify(result));
//         }else
//         {
//             response.send("Something went wrong!"); 
//         }
//     });
// });

router.delete('/del_w:id',(request,response)=>{
    const {id}=request.params;
    const connection=db.connect()
    const statement=`delete from t_writer where writer_id=${id}`
    connection.query(statement,(error,data)=>{
        connection.end()
        response.send(utils.createresult(error,data))
    })
})

router.put('/:id',(request,response)=>{
    const {id}=request.params;
    const connection=db.connect()
    const{name,gender,email_id,mobile_no,address,dob,password,t_role}=request.body
    const statement=`update t_writer set name='${name}',gender='${gender}',email_id='${email_id}',mobile_no='${mobile_no}',address='${address}',dob='${dob}',password='${password}',t_role='${t_role}' where writer_id=${id}`
    connection.query(statement,(error,data)=>{
        connection.end()
        response.send(utils.createresult(error,data))
    })

})

router.put('/change_password:email_id',(request,response)=>{
    const {email_id}=request.params;
    const connection=db.connect()
    const{cpassword}=request.body
    const statement=`update t_writer set password='${cpassword}' where writer_id=${email_id}`
    connection.query(statement,(error,data)=>{
        connection.end()
        response.send(utils.createresult(error,data))
    })

})



module.exports = router