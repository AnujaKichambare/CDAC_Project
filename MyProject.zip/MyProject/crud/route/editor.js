const db=require('./db')
const utils=require('./utils')
const express =require('express')

const router=express.Router();



router.get("/listofwriter",function(request,response){
    const connection=db.connect()
    connection.query(`select * from t_writer where t_role='w'`,function(err,result){
        if(err==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(result));
        }else
        {
            response.send("Something went wrong!"); 
        }
    });
});

router.post('/register',(request,response)=>{
    const{name,gender,email_id,mobile_no,address,dob,password,t_role}=request.body
    const connection=db.connect()
    const statement=`insert into t_writer (name,gender,email_id,mobile_no,address,dob,password,t_role) values('${name}','${gender}','${email_id}','${mobile_no}','${address}','${dob}','${password}','${t_role}')`
   //console.log(statement);
    connection.query(statement,(err,data)=>{
        connection.end()
        if(err==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }
    })
})

router.get("/getwriter/:id",function(request,response){
    let eno=parseInt(request.params.id);
    const connection=db.connect()
    connection.query(`select * from t_writer where writer_id=${eno}`,function(err,result){
   //    console.log(result)
        if(err==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(result));
        }else
        {
            response.send("Something went wrong!"); 
        }
    });
});

router.post('/editwriter',(request,response)=>{
    const connection=db.connect()
    const{writer_id,name,gender,email_id,mobile_no,address,dob,password,t_role}=request.body
    const statement=`update t_writer set name='${name}',gender='${gender}',email_id='${email_id}',mobile_no='${mobile_no}',address='${address}',dob='${dob}',password='${password}',t_role='${t_role}' where writer_id=${writer_id}`
    console.log(statement);
    connection.query(statement,(err,data)=>{
        if(err==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })

})

router.get('/deletewriter/:id',(request,response)=>{
    const {id}=request.params;
    const connection=db.connect()
    const statement=`delete from t_writer where writer_id=${id}`
    connection.query(statement,(error,data)=>{
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})

router.get('/changepassword/:email_id/:password',(request,response)=>{
    const {email_id}=request.params;
    //console.log(email_id);
    
    const {password}=request.params;
    console.log(password);
    const connection=db.connect()
    const statement=`update t_writer set password='${password}' where email_id='${email_id}'`
    console.log(statement);
    connection.query(statement,(error,data)=>{
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})

router.get('/getpoll',(request,response)=>{
    const connection=db.connect()
    const statement=`select * from t_poll where status='e'`
    connection.query(statement,(error,data)=>{
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }        
    })
})

router.post('/addpoll',(request,response)=>{
    const connection=db.connect()
    const{add_poll,opt_A,opt_B,opt_C,opt_D}=request.body
    const status='e';
    //const valid_upto="2020-01-25";
    const statement=`insert into t_poll (add_poll,opt_A,opt_B,opt_C,opt_D,status) values('${add_poll}','${opt_A}','${opt_B}','${opt_C}','${opt_D}','${status}')`
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})

router.get('/deletepoll/:poll_id',(request,response)=>{
    const {poll_id}=request.params;
    const connection=db.connect()
    const statement=`update t_poll set status='d' where poll_id=${poll_id}`
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})

router.get('/setanswer/:poll_id/:ans',(request,response)=>{
    const {poll_id}=request.params;
    const connection=db.connect()
    const {ans}=request.params;
    const statement=`insert into t_poll_result (poll_id,ans) values(${poll_id},'${ans}')`
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})


router.get('/addcategory/:category_name',(request,response)=>{
    const {category_name}=request.params;
    const connection=db.connect()

    const statement=`insert into t_categories (category_name) values('${category_name}')`
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})



router.get('/getuploadednews/:language',(request,response)=>{
    //count is remaning
    const {language}=request.params
    const connection=db.connect()
    const statement=`select * from t_news where flag='true' and language='${language}' order by upload_date desc,upload_time desc`
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})



router.get('/getunuploadednews',(request,response)=>{
    //count is remaning
    const {language}=request.params
    const connection=db.connect()
    const statement=`select * from t_news where flag='false' order by upload_date desc,upload_time desc`
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})


router.get('/uploadnews/:nid',(request,response)=>{
    //count is remaning
    const {nid}=request.params
    console.log(nid);
    const connection=db.connect()
    const statement=`update t_news set flag='true' where news_id=${nid}`
    console.log(statement);
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})


router.get('/unuploadnews/:nid',(request,response)=>{
    //count is remaning
    const {nid}=request.params
    console.log(nid);
    const connection=db.connect()
    const statement=`update t_news set flag='false' where news_id=${nid}`
    console.log(statement);
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})



router.get('/getallnews',(request,response)=>{
    //count is remaning
    const {language}=request.params
    const connection=db.connect()
    const statement=`select * from t_news order by upload_date desc,upload_time desc`
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})



router.put('/editnews/:category_id/:nid',(request,response)=>{
    const {category_id}=request.params
    const {nid}=request.params    
    const {title,description,link,lang,image_video,date,time,flag}=request.body
    const statement=`update t_news set news_title='${title}',news_description='${description}',news_link='${link}'category_id='${category_id}',language='${lang}'image_video='${image_video}',upload_date='${date}',upload_time='${time}',flag='${flag} where news_id=${nid}`
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})

router.get('/deletenews/:id',(request,response)=>{
    const {id}=request.params;
    const connection=db.connect()
    const statement=`delete from t_news where news_id=${id}`
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})

router.put('/addnews/:cid',(request,response)=>{
    const {cid}=request.params
    const {news_title,news_description,news_link,language,image_video}=request.body
    var today=new Date();
    var day=today.getFullYear();
    var month=today.getMonth()+1;
    var year=today.getDate();


		// if(day<10&&month<10)
		// {
		// cdate=year+"/0"+month+"/0"+day;	
		// }
		// if(month<10)
		// {
		// cdate=year+"/0"+month+"/"+day;
        // }
        // if(day<10)
		// {
		// cdate=year+"/"+month+"/0"+day;
		// }else {
		// cdate=year+"/"+month+"/"+day;
		// }
        //     console.log(cdate);
        //       var date=cdate;  
        var date=year+"-"+month+"-"+day;
        console.log(date);
    var time=today.getHours()+"-"+today.getMinutes()+"-"+today.getSeconds();
    console.log(date);
    console.log(time);


    const flag='false';
    const connection=db.connect()
    const statement=`insert into t_news (news_title,news_description,news_link,category_id,language,image_video,upload_date,flag,upload_time) values('${news_title}','${news_description}','${news_link}','${cid}','${language}','${image_video}','${date}','${flag}','${time}')`
    console.log(statement);
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { console.log(data);
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {console.log(error);
            response.send("Something went wrong!"); 
        }

    })
})


router.get('/addcategory/:cname',(request,response)=>{
    const {cname}=request.params;
    const connection=db.connect()
    const statement=`insert into t_categories (category_name) values('${cname}')`
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})





module.exports=router