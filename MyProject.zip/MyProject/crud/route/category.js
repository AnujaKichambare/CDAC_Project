const db=require('./db')
const utils=require('./utils')
const express =require('express')

const router=express.Router();

router.get('/getcategory',(request,response)=>{
    const connection=db.connect()
    const statement=`select * from t_categories`
    connection.query(statement,(error,data)=>{
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }        
    })
})

router.get("/:category_id",(request,response)=>{
    const {category_id}=request.params
    const connection=db.connect()
    const statement=`select * from t_categories where category_id=${category_id}`
    connection.query(statement,(error,data)=>{
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }        
    })

})



module.exports=router