const db=require('./db')
const utils=require('./utils')
const express =require('express')

const router=express.Router();

router.post('/check',(request,response)=>{
    const {email_id,password}=request.body
    const connection=db.connect()
    const statement=`select * from t_writer where email_id='${email_id}' && password='${password}'`
   console.log(statement);
    connection.query(statement,(error,data)=>{
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})

router.get('/listofcatagory',(request,response)=>{
    const connection=db.connect()
    const statement=`select * from t_categories`
    connection.query(statement,(error,data)=>{
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
        response.send("Something went wrong!"); 
        }

    })
})



router.get('/listofcatagory',(request,response)=>{
    const connection=db.connect()

    const statement=`select * from t_categories`
    connection.query(statement,(error,data)=>{
        connection.end()
        if(error==null)
        { 
    response.contentType("application/json");
    response.send(JSON.stringify(data));
        }else
        {
            response.send("Something went wrong!"); 
        }

    })
})


module.exports=router